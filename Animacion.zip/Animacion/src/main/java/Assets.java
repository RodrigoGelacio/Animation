/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.image.BufferedImage;

/**
 *
 * @author antoniomejorado
 */
public class Assets {
    public static BufferedImage background; // to store background image
    public static BufferedImage player;     // to store the player image
    public static BufferedImage sprite;
    public static BufferedImage up[];
    public static BufferedImage down[];
    public static BufferedImage left[];
    public static BufferedImage right[];
    /**
     * initializing the images of the game
     */
    public static void init() {
        background = ImageLoader.loadImage("/images/background.png");
        player = ImageLoader.loadImage("/images/sanic.png");
        sprite = ImageLoader.loadImage("/images/sprite.png");
        Spritesheet spritesheet = new Spritesheet(sprite);
        up = new BufferedImage[4];
        down = new BufferedImage[4];
        left = new BufferedImage[4];
        right = new BufferedImage[4];
        
        for(int i=0; i < 4; i++){
               up[i] = spritesheet.crop(i * 256, 0, 800, 1600);
               left[i] = spritesheet.crop(i * 256, 256, 800, 1600);
               down[i] = spritesheet.crop(i * 256, 512, 800, 1600);
               right[i] = spritesheet.crop(i * 256, 568, 800, 1600);
        }
        
    }
    
}
