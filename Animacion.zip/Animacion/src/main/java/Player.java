/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Graphics;
import java.awt.event.KeyEvent;

/**
 *
 * @author Rodrigo Torres
 */
public class Player extends Item {

    private int direction;
    private Game game;
    private int counter;
    private Animation animationUp;
    private Animation animationDown;
    private Animation animationLeft;
    private Animation animationRight;

    public Player(int x, int y, int direction, int width, int height, Game game, int counter) {
        super(x, y, width, height);
        this.direction = direction;
        this.game = game;
        this.counter = counter;
        
        this.animationUp = new Animation(Assets.up, 100);
        this.animationDown = new Animation(Assets.down, 100);
        this.animationLeft = new Animation(Assets.left, 100);
        this.animationRight = new Animation(Assets.right, 100);
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    @Override
    public void tick() {
        // moving player depending on flags and velocity

        this.animationRight.tick();

        // if it hits a wall, it bounces in the opposite direction by pressing 
        //virtually a button.
        if (getX() + 60 >= game.getWidth()) {
            setX(game.getWidth()- 60);
        } else if (getX() <= -30) {
            setX(-30);
        }
        if (getY() + 80 >= game.getHeight()) {
            setY(game.getHeight()- 80);
        } else if (getY() <= -20) {
            setY(-20);
        }
    }

    @Override
    public void render(Graphics g) {
        g.drawImage(animationRight.getCurrentFrame(), getX(), getY(), getWidth(), getHeight(), null);
    }
}
